import numpy as np

def crossover(parent1, parent2):
    """
    Single-point crossover for schedules.
    """
    point = np.random.randint(1, len(parent1.schedule) - 1)
    child1 = np.concatenate((parent1.schedule[:point], parent2.schedule[point:]))
    child2 = np.concatenate((parent2.schedule[:point], parent1.schedule[point:]))
    return child1, child2

def mutate(schedule, mutation_rate=0.1):
    """
    Swap mutation for schedules.
    """
    for i in range(len(schedule)):
        if np.random.rand() < mutation_rate:
            j = np.random.randint(0, len(schedule))
            schedule[i], schedule[j] = schedule[j], schedule[i]
    return schedule
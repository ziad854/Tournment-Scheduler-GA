def evaluate_fitness(schedule, constraints):
    """
    Fitness function to evaluate the quality of a schedule.
    :param schedule: The schedule to evaluate.
    :param constraints: Constraints to consider.
    :return: Fitness score (higher is better).
    """
    score = 0

    # Example: Minimize venue conflicts
    score -= count_venue_conflicts(schedule)

    # Example: Ensure fair rest periods
    score -= count_rest_violations(schedule, constraints)

    # Example: Balance game times
    score -= count_time_imbalances(schedule)

    return score